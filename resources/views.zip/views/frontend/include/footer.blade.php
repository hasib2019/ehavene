        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-4 col-xs-12">
                        <div class="footer-logo">
                            <a class="brand" href="https://dinratri.aapbd.com/index"><img src="{{asset('./files/Logo_orange.png')}}" alt=" Logo "></a>
                        </div>
                        <p> © 2019 Dinratri.com </p>
                        <div>
                            <input type="text" placeholder="Enter your email" style="height: 40px;width:200px;padding:19px;border:none;border-radius: 5px;background-color: rgba(0,0,0,0.20);">
                            <input type="submit" value="Subscribe" style="margin-left:-21px;;border:none;border-radius:5px;background-color: #E88139;color:white;padding:10px;">
                        </div>

                    </div>
                    <div class="col-sm-2 col-md-2 col-xs-12 collapsed-block">
                        <div class="footer-links">
                            <h5 class="links-title">About<a class="expander visible-xs" href="https://dinratri.aapbd.com/#TabBlock-3">+</a></h5>
                            <div class="tabBlock" id="TabBlock-3">
                                <ul class="list-links list-unstyled">
                                    <li><a href="https://dinratri.aapbd.com/index">Home</a></li>
                                    <li><a href="https://dinratri.aapbd.com/blog">The Blog</a></li>
                                    <li><a href="https://dinratri.aapbd.com/aboutus">About us</a></li>
                                    <li><a href="https://dinratri.aapbd.com/aboutus">Careers</a></li>
                                    <li><a href="https://dinratri.aapbd.com/aboutus">Dinratri Stories</a></li>

                                    <li><a href="https://dinratri.aapbd.com/cms/15">
                                      Privacy</a>
                                    </li>
                                    <li><a href="https://dinratri.aapbd.com/cms/14">
                                      Returns Policy</a>
                                    </li>
                                    <li><a href="https://dinratri.aapbd.com/cms/9">
                                      Security</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2 col-md-2 col-xs-12 collapsed-block">
                        <div class="footer-links">
                            <h5 class="links-title">HELP<a class="expander visible-xs" href="https://dinratri.aapbd.com/#TabBlock-3">+</a></h5>
                            <div class="tabBlock" id="TabBlock-3">
                                <ul class="list-links list-unstyled">
                                    <li><a href="https://dinratri.aapbd.com/#">Payments</a></li>
                                    <li><a href="https://dinratri.aapbd.com/#">Shipping</a></li>
                                    <li><a href="https://dinratri.aapbd.com/#">Cancellations &amp; Returns</a></li>
                                    <li><a href="https://dinratri.aapbd.com/#">FAQ</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2 col-md-2 col-xs-12 collapsed-block">
                        <div class="footer-links">
                            <h5 class="links-title">POLICY<a class="expander visible-xs" href="https://dinratri.aapbd.com/#TabBlock-3">+</a></h5>
                            <div class="tabBlock" id="TabBlock-3">
                                <ul class="list-links list-unstyled">
                                    <li><a href="https://dinratri.aapbd.com/#">Security</a></li>
                                    <li><a href="https://dinratri.aapbd.com/#">Privacy</a></li>
                                    <li><a href="https://dinratri.aapbd.com/#">Return policy</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2 col-md-2 col-xs-12 collapsed-block">
                        <div class="footer-links">
                            <h5 class="links-title">SOCIAL<a class="expander visible-xs" href="https://dinratri.aapbd.com/#TabBlock-3">+</a></h5>
                            <div class="tabBlock" id="TabBlock-3">
                                <ul class="list-links list-unstyled">
                                    <li><i class="fa fa-facebook" style="background-color: white;color:#333333;width:12px;border-radius: 50%;text-align: center;"></i>&nbsp;&nbsp;<a href="https://dinratri.aapbd.com/#">Facebook</a></li>
                                    <li><i class="fa fa-instagram" style="background-color: white;color:#333333;width:12px;border-radius: 50%;text-align: center;"></i>&nbsp;&nbsp;<a href="https://dinratri.aapbd.com/#">Instagram</a></li>
                                    <li><i class="fa fa-twitter" style="background-color: white;color:#333333;width:12px;border-radius: 50%;text-align: center;"></i>&nbsp;&nbsp;<a href="https://dinratri.aapbd.com/#">Twitter</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="footer-coppyright">
                <div class="container">
                    <div class="row" style="padding-bottom:19px;padding-top:19px;">
                        <div class="col-sm-3 col-xs-12 coppyright">
                            <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/Button - App Store 2.png')}}"></a>
                            <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/Button - Play Store 2.png')}}" style="margin-left:10px;"></a>
                        </div>
                        <div class="col-sm-4 col-xs-12" style="margin-top:22px;">
                            <a href="https://dinratri.aapbd.com/#"><i class="fa fa-shopping-bag" style="padding-right:4px;color:#CB356B;font-size:13px;"></i>&nbsp;<span style="padding-left: 2px;padding-right: 15px;">Sell on Dinratri</span></a>
                            <a href="https://dinratri.aapbd.com/#"><i class="fa fa-gift" style="padding-right:4px;color:#CB356B;font-size:13px;"></i>&nbsp;<span style="padding-left: 2px;padding-right: 15px;">Gift Cards</span></a>
                            <a href="https://dinratri.aapbd.com/#"><i class="fa fa-comments" style="padding-right:4px;color:#CB356B;font-size:13px;"></i>&nbsp;<span style="padding-left: 2px;">Support Center</span></a>
                        </div>
                        <div class="col-sm-5 col-xs-12">
                            <ul class="footer-company-links">
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1.svg')}}"></a>
                                </li>
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1 copy.svg')}}"></a>
                                </li>
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1 copy 2.svg')}}"></a>
                                </li>
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1 copy 3.svg')}}"></a>
                                </li>
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1 copy 4.svg')}}"></a>
                                </li>
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1 copy 5.svg')}}"></a>
                                </li>
                                <li>
                                    <a href="https://dinratri.aapbd.com/#"><img src="{{asset('./files/1 copy 6.svg')}}"></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>