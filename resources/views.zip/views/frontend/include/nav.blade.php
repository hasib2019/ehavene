 <nav>
     <div class="container">
         <div class="row">
             <div class="mm-toggle-wrap">
                 <div class="mm-toggle"><i class="fa fa-align-justify"></i> </div>
                 <span class="mm-label"> All Categories </span>
             </div>
             <div class="col-md-3 col-sm-3 mega-container hidden-xs">
                 <div class="navleft-container">
                     <div class="mega-menu-title">
                         <h3><span>All Departments</span></h3>
                     </div>

                     <!-- Shop by category -->
                     <div class="mega-menu-category">
                         <ul class="nav">
                             <li><a href="https://dinratri.aapbd.com/catproducts/viewcategorylist/MSwyMjI=">

                                     WOMEN
                                 </a>

                                 <div class="wrap-popup column1">
                                     <div class="popup">
                                         <ul class="nav">
                                             <li><a
                                                     href="https://dinratri.aapbd.com/catproducts/viewcategorylist/Miw3MA==">

                                                     CLOTHING
                                                 </a>
                                             </li>
                                         </ul>
                                     </div>
                                 </div>
                             </li>
                             <li><a href="https://dinratri.aapbd.com/catproducts/viewcategorylist/MSwyMjQ=">

                                     ELECTRONICS
                                 </a>

                                 <div class="wrap-popup column1">
                                     <div class="popup">
                                         <ul class="nav">
                                             <li><a
                                                     href="https://dinratri.aapbd.com/catproducts/viewcategorylist/Miw5Mg==">

                                                     HOME APPLIANCES
                                                 </a>
                                             </li>
                                         </ul>
                                     </div>
                                 </div>
                             </li>
                             <li><a href="https://dinratri.aapbd.com/catproducts/viewcategorylist/MSwyMjU=">

                                     HOME APPLIANCE
                                 </a>

                                 <div class="wrap-popup column1">
                                     <div class="popup">
                                         <ul class="nav">
                                             <li><a
                                                     href="https://dinratri.aapbd.com/catproducts/viewcategorylist/Miw5OA==">

                                                     KITCHEN
                                                 </a>
                                                 <div class="wrap-popup column1">
                                                     <div class="popup1">
                                                         <ul class="nav">
                                                             <li><a
                                                                     href="https://dinratri.aapbd.com/catproducts/viewcategorylist/MywyNzg="><span>

                                                                         Kitchen Appliances
                                                                     </span></a>
                                                             </li>
                                                         </ul>
                                                     </div>
                                                 </div>
                                             </li>
                                         </ul>
                                     </div>
                                 </div>
                             </li>

                             <li><a href="https://dinratri.aapbd.com/category_list_all"><span>
                                         More Categories
                                     </span></a>
                             </li>
                         </ul>
                     </div>
                 </div>
             </div>

             <div class="col-md-7 col-sm-7 jtv-megamenu">
                 <div class="mtmegamenu">
                     <ul id="res_menu">

                         <!--<li class="mt-root">
                <div class="mt-root-item"><a href="#">
                  <div class="title title_font"><span class="title-text">Categories</span></div>
                  </a></div>
                <ul class="menu-items col-xs-12">
                  <li class="menu-item depth-1 menucol-1-3 ">
                    <div class="title title_font"> <a href="#">Fashion</a></div>
                    <ul class="submenu">
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Women</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Men</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Kids</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Clothings</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Shoes</a></div>
                      </li>
                    </ul>
                  </li>
                  <li class="menu-item depth-1 menucol-1-3 ">
                    <div class="title title_font"> <a href="#">Electronics </a></div>
                    <ul class="submenu">
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Mobiles</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Computers</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Headphones</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Laptops</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Appliances</a></div>
                      </li>
                    </ul>
                  </li>
                  <li class="menu-item depth-1 menucol-1-3 ">
                    <div class="title title_font"> <a href="#">Beauty & Health</a></div>
                    <ul class="submenu">
                      <li class="menu-item depth-2 category ">
                        <div class="title"> <a href="shop_grid.html">Face Care</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Skin Care</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Minerals</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Body Care</a></div>
                      </li>
                      <li class="menu-item">
                        <div class="title"> <a href="shop_grid.html">Cosmetic</a></div>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>-->

                         <li class="active mt-root">
                             <div class="mt-root-item">
                                 <a href="https://dinratri.aapbd.com/products">
                                     <div class="title title_font"><span class="title-text">Men</span></div>
                                 </a>
                             </div>
                         </li>

                         <li class="active mt-root">
                             <div class="mt-root-item">
                                 <a href="https://dinratri.aapbd.com/deals">
                                     <div class="title title_font"><span class="title-text">Women</span></div>
                                 </a>
                             </div>
                         </li>

                         <li class="active mt-root">
                             <div class="mt-root-item">
                                 <a href="https://dinratri.aapbd.com/sold">
                                     <div class="title title_font"><span class="title-text">Kids</span></div>
                                 </a>
                             </div>
                         </li>

                         <li class="active mt-root">
                             <div class="mt-root-item">
                                 <a href="https://dinratri.aapbd.com/stores">
                                     <div class="title title_font"><span class="title-text">Home</span></div>
                                 </a>
                             </div>
                         </li>

                         <li class="active mt-root">
                             <div class="mt-root-item">
                                 <a href="https://dinratri.aapbd.com/nearbystore">
                                     <div class="title title_font"><span class="title-text">Electronics</span></div>
                                 </a>
                             </div>
                         </li>

                         <li class="active mt-root">
                             <div class="mt-root-item">
                                 <a href="https://dinratri.aapbd.com/contactus">
                                     <div class="title title_font"><span class="title-text">Shoes</span></div>
                                 </a>
                             </div>
                         </li>
                     </ul>

                 </div>
             </div>
             <!-- add phone number start-->
             <div class="col-md-2 col-sm-2">

                 <div class="call_number text-right">
                     <a href="tel:+8801972744733"><img src="images/icon_phone.svg" alt="">+8801972744733</a>
                 </div>
             </div>
             <!-- add phone number end-->
         </div>
     </div>
 </nav>
