@extends('frontend.layouts.app')

@section('content')

<h1>Address show</h1>



@endsection

@section('script')

@endsection
